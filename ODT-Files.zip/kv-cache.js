// ═══════════════════════════════════════════════════════════════════
// IceCache-Inspired KV-Cache Manager for ODT
// Memory-efficient context caching for long-context LLM inference
// ═══════════════════════════════════════════════════════════════════

var KVCache = {
  // Cache storage - organized in pages like IceCache
  pages: new Map(),
  pageSize: 64,  // tokens per page (like leaf nodes in DCI-tree)
  maxPages: 256, // maximum pages in memory
  maxMemoryMB: 10, // ~10MB localStorage limit per key
  
  // Semantic index - maps concepts to pages
  semanticIndex: new Map(),
  
  // LRU tracking
  accessOrder: [],
  accessIndex: new Map(),
  
  // Statistics
  stats: {
    hits: 0,
    misses: 0,
    evictions: 0,
    totalTokens: 0
  }
};

// Create semantic embedding from text (simplified hash-based)
function createSemanticKey(text) {
  var words = text.toLowerCase().split(/\s+/);
  var hash = 0;
  for (var i = 0; i < words.length; i++) {
    hash = ((hash << 5) - hash) + words[i].charCodeAt(0);
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

// Tokenize text into page-sized chunks
function tokenizeToPages(text, pageSize) {
  var words = text.split(/\s+/);
  var pages = [];
  var currentPage = [];
  var currentTokens = 0;
  
  for (var i = 0; i < words.length; i++) {
    currentPage.push(words[i]);
    currentTokens++;
    
    if (currentTokens >= pageSize) {
      pages.push({
        id: 'page-' + Date.now() + '-' + pages.length,
        tokens: currentPage.join(' '),
        tokenCount: currentTokens,
        semanticKey: createSemanticKey(currentPage.join(' '))
      });
      currentPage = [];
      currentTokens = 0;
    }
  }
  
  if (currentPage.length > 0) {
    pages.push({
      id: 'page-' + Date.now() + '-' + pages.length,
      tokens: currentPage.join(' '),
      tokenCount: currentTokens,
      semanticKey: createSemanticKey(currentPage.join(' '))
    });
  }
  
  return pages;
}

// Index pages into semantic structure (like DCI-tree)
function indexPage(page) {
  var semanticKey = page.semanticKey;
  
  if (!KVCache.semanticIndex.has(semanticKey)) {
    KVCache.semanticIndex.set(semanticKey, []);
  }
  
  var indexList = KVCache.semanticIndex.get(semanticKey);
  if (!indexList.find(p => p.id === page.id)) {
    indexList.push(page);
  }
  
  // Also index by first word for quick lookup
  var firstWord = page.tokens.split(/\s+/)[0];
  if (!KVCache.semanticIndex.has(firstWord)) {
    KVCache.semanticIndex.set(firstWord, []);
  }
  var firstList = KVCache.semanticIndex.get(firstWord);
  if (!firstList.find(p => p.id === page.id)) {
    firstList.push(page);
  }
}

// Store context in cache with page-based organization
function cacheContext(key, context, maxPages) {
  var pages = tokenizeToPages(context, KVCache.pageSize);
  var storedPages = [];
  
  for (var i = 0; i < pages.length; i++) {
    if (KVCache.pages.size >= KVCache.maxPages) {
      evictLRUPage();
    }
    
    var page = pages[i];
    KVCache.pages.set(page.id, {
      ...page,
      parentKey: key,
      created: Date.now(),
      lastAccess: Date.now()
    });
    
    indexPage(page);
    storedPages.push(page);
    KVCache.stats.totalTokens += page.tokenCount;
  }
  
  // Track access order for LRU
  KVCache.accessOrder.push({ key: key, pages: storedPages.map(p => p.id), timestamp: Date.now() });
  KVCache.accessIndex.set(key, storedPages.map(p => p.id));
  
  // Persist to localStorage
  persistCache();
  
  return storedPages.length;
}

// Retrieve context from cache (bulk loading like IceCache)
function getCachedContext(key) {
  var pageIds = KVCache.accessIndex.get(key);
  
  if (!pageIds || pageIds.length === 0) {
    KVCache.stats.misses++;
    return null;
  }
  
  var pages = [];
  for (var i = 0; i < pageIds.length; i++) {
    var page = KVCache.pages.get(pageIds[i]);
    if (page) {
      pages.push(page);
      page.lastAccess = Date.now();
    }
  }
  
  if (pages.length > 0) {
    KVCache.stats.hits++;
    return pages.sort((a, b) => a.id.localeCompare(b.id)).map(p => p.tokens).join(' ');
  }
  
  KVCache.stats.misses++;
  return null;
}

// Semantic search - find relevant pages like IceCache's tree search
function findRelevantPages(query, topK) {
  var queryWords = query.toLowerCase().split(/\s+/);
  var relevance = new Map();
  
  // Score pages by relevance to query
  for (var i = 0; i < queryWords.length; i++) {
    var word = queryWords[i];
    var matchingPages = KVCache.semanticIndex.get(word) || [];
    
    for (var j = 0; j < matchingPages.length; j++) {
      var page = matchingPages[j];
      var score = relevance.get(page.id) || 0;
      relevance.set(page.id, score + 1);
    }
  }
  
  // Sort by relevance
  var sorted = Array.from(relevance.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, topK);
  
  // Bulk load relevant pages
  var pages = [];
  for (var i = 0; i < sorted.length; i++) {
    var page = KVCache.pages.get(sorted[i][0]);
    if (page) {
      pages.push(page);
      page.lastAccess = Date.now();
    }
  }
  
  return pages;
}

// Get context for LLM with relevance to query (IceCache-style)
function getRelevantContext(query, maxTokens) {
  var relevantPages = findRelevantPages(query, Math.ceil(maxTokens / KVCache.pageSize));
  var context = [];
  var totalTokens = 0;
  
  for (var i = 0; i < relevantPages.length; i++) {
    if (totalTokens + relevantPages[i].tokenCount <= maxTokens) {
      context.push(relevantPages[i].tokens);
      totalTokens += relevantPages[i].tokenCount;
    }
  }
  
  return context.join(' ');
}

// Evict LRU page (like IceCache's page selection)
function evictLRUPage() {
  var oldestKey = null;
  var oldestTime = Infinity;
  
  for (var page of KVCache.pages) {
    if (page[1].lastAccess < oldestTime) {
      oldestTime = page[1].lastAccess;
      oldestKey = page[0];
    }
  }
  
  if (oldestKey) {
    var page = KVCache.pages.get(oldestKey);
    if (page) {
      // Remove from semantic index
      var semList = KVCache.semanticIndex.get(page.semanticKey);
      if (semList) {
        semList = semList.filter(p => p.id !== oldestKey);
        if (semList.length === 0) {
          KVCache.semanticIndex.delete(page.semanticKey);
        }
      }
      
      KVCache.pages.delete(oldestKey);
      KVCache.stats.evictions++;
      KVCache.stats.totalTokens -= page.tokenCount;
    }
  }
}

// Persist cache to localStorage
function persistCache() {
  try {
    var cacheData = {
      pages: Array.from(KVCache.pages.entries()),
      semanticIndex: Array.from(KVCache.semanticIndex.entries()),
      accessIndex: Array.from(KVCache.accessIndex.entries()),
      accessOrder: KVCache.accessOrder.slice(-100),
      stats: KVCache.stats
    };
    
    var serialized = JSON.stringify(cacheData);
    
    // Check size
    if (serialized.length > 5 * 1024 * 1024) { // 5MB limit
      // Evict some pages
      while (serialized.length > 4 * 1024 * 1024 && KVCache.pages.size > 10) {
        evictLRUPage();
        cacheData = {
          pages: Array.from(KVCache.pages.entries()),
          semanticIndex: Array.from(KVCache.semanticIndex.entries()),
          accessIndex: Array.from(KVCache.accessIndex.entries()),
          accessOrder: KVCache.accessOrder.slice(-50),
          stats: KVCache.stats
        };
        serialized = JSON.stringify(cacheData);
      }
    }
    
    localStorage.setItem('odt_kvcache', serialized);
  } catch (e) {
    console.warn('[KVCache] Persist failed:', e.message);
    // Clear old entries and retry
    localStorage.removeItem('odt_kvcache');
  }
}

// Load cache from localStorage
function loadCache() {
  try {
    var data = localStorage.getItem('odt_kvcache');
    if (data) {
      var parsed = JSON.parse(data);
      KVCache.pages = new Map(parsed.pages);
      KVCache.semanticIndex = new Map(parsed.semanticIndex);
      KVCache.accessIndex = new Map(parsed.accessIndex);
      KVCache.accessOrder = parsed.accessOrder || [];
      KVCache.stats = parsed.stats || KVCache.stats;
      console.log('[KVCache] Loaded ' + KVCache.pages.size + ' pages');
    }
  } catch (e) {
    console.warn('[KVCache] Load failed:', e.message);
    localStorage.removeItem('odt_kvcache');
  }
}

// Build agent context with KV-cache
function buildCachedAgentContext(session) {
  var ctx = session.context;
  var cachedHistory = getCachedContext(session.id);
  
  var context = {
    project: ctx.project?.name || 'Unknown',
    currentFile: ctx.currentFile?.name || 'None',
    openFiles: ctx.openFiles?.map(f => f.name).join(', ') || 'None',
    recentAgentHistory: cachedHistory || ''
  };
  
  return context;
}

// Cache agent conversation turns
function cacheAgentMessage(sessionId, role, content) {
  var key = 'agent-' + sessionId;
  var existing = getCachedContext(key) || '';
  
  var newContent = existing + '\n' + role + ': ' + content.substring(0, 500);
  
  // Re-cache with new content
  var pageIds = KVCache.accessIndex.get(key);
  if (pageIds) {
    for (var i = 0; i < pageIds.length; i++) {
      KVCache.pages.delete(pageIds[i]);
    }
  }
  
  cacheContext(key, newContent, 50);
}

// Get cache statistics
function getKVCacheStats() {
  var totalPages = KVCache.pages.size;
  var totalTokens = KVCache.stats.totalTokens;
  var hitRate = KVCache.stats.hits + KVCache.stats.misses > 0 
    ? (KVCache.stats.hits / (KVCache.stats.hits + KVCache.stats.misses) * 100).toFixed(1) + '%' 
    : '0%';
  
  return {
    pages: totalPages,
    tokens: totalTokens,
    hitRate: hitRate,
    evictions: KVCache.stats.evictions,
    memory: Math.round(JSON.stringify(Array.from(KVCache.pages.entries())).length / 1024) + 'KB'
  };
}

// Clear cache
function clearKVCache() {
  KVCache.pages.clear();
  KVCache.semanticIndex.clear();
  KVCache.accessIndex.clear();
  KVCache.accessOrder = [];
  localStorage.removeItem('odt_kvcache');
  console.log('[KVCache] Cleared');
}

// Initialize
loadCache();

// Periodic cleanup and persistence
setInterval(() => {
  if (KVCache.pages.size > 0) {
    persistCache();
  }
}, 30000);

// Export for window use
window.KVCache = KVCache;
window.cacheContext = cacheContext;
window.getCachedContext = getCachedContext;
window.getRelevantContext = getRelevantContext;
window.cacheAgentMessage = cacheAgentMessage;
window.getKVCacheStats = getKVCacheStats;
window.clearKVCache = clearKVCache;

console.log('[KVCache] IceCache-inspired context cache initialized');