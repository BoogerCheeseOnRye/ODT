@echo off
title ODT Setup Wizard
color 0A
cd /d "E:\ODT(ignore do not delete)\backup4"

echo.
echo  ================================================
echo   ODT Setup Wizard - Omni Development Terminal
echo  ================================================
echo.

:: Check for admin/elevated privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Running setup...
)

:: ============================================
:: STEP 1: Check Internet Connection
:: ============================================
echo [1/7] Checking network connection...

:: Test different network types
ping -n 1 8.8.8.8 >nul 2>&1
set "NETWORK_TYPE=unknown"
if %errorlevel% equ 0 set "NETWORK_TYPE=wired"

:: Check for common 5G wireless indicators
ipconfig | findstr /i "192.168.168" >nul 2>&1
if %errorlevel% equ 0 set "NETWORK_TYPE=5g_wireless"

:: Check T-Mobile indicators
ipconfig | findstr /i "192.168.224" >nul 2>&1
if %errorlevel% equ 0 set "NETWORK_TYPE=tmobile_5g"

:: Check WiFi adapter presence
netsh wlan show interfaces | findstr /i "SSID" >nul 2>&1
if %errorlevel% equ 0 (
    if "%NETWORK_TYPE%"=="unknown" set "NETWORK_TYPE=wifi"
)

echo    Network detected: %NETWORK_TYPE%

:: ============================================
:: STEP 2: Check Node.js and Dependencies
:: ============================================
echo [2/7] Checking Node.js...

node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo    Node.js not found! Installing via winget...
    winget install OpenJS.NodeJS --silent --accept-source-agreements --accept-package-agreements
    timeout /t 5 /nobreak >nul
)

node --version
echo    Node.js OK

:: Install dependencies if package.json exists
if exist "package.json" (
    echo    Installing npm dependencies...
    call npm install --silent 2>nul
)

:: ============================================
:: STEP 3: Check and Install Ollama
:: ============================================
echo [3/7] Checking Ollama...

where ollama >nul 2>&1
if %errorlevel% neq 0 (
    echo    Ollama not found!
    echo    Installing Ollama for Windows...
    powershell -Command "irm https://ollama.com/install.ps1 | iex"
) else (
    echo    Ollama installed
)

:: ============================================
:: STEP 4: Scan All Drives for LLM Models
:: ============================================
echo [4/7] Scanning drives for LLM models...

set "LLM_PATHS_FILE=%TEMP%\odt_llm_paths.txt"
if exist "%LLM_PATHS_FILE%" del "%LLM_PATHS_FILE%"

:: Common model locations (GGUF, Ollama, etc)
set "SEARCH_PATHS=C:\ollama-models;D:\OLLAMA\models;E:\ollama-models;%USERPROFILE%\.ollama\models;C:\Users\%USERNAME%\AppData\Local\ollama\models;%USERPROFILE%\AppData\Local\Programs\Ollama\models;%USERPROFILE%\.cache\ollama\models"

:: Create output file
echo # ODT LLM Model Scan > "%LLM_PATHS_FILE%"
echo # Generated: %DATE% %TIME% >> "%LLM_PATHS_FILE%"
echo. >> "%LLM_PATHS_FILE%"

:: GGUF files (llama.cpp format)
echo [Scanning for GGUF files...]
for %%P in (%SEARCH_PATHS%) do (
    if exist "%%P" (
        echo    Scanning %%P
        for /r "%%P" %%F in (*.gguf) do (
            echo GGUF %%F >> "%LLM_PATHS_FILE%"
        )
    )
)

:: Ollama blob files (sha256 hashes)
echo [Scanning for Ollama models...]
for /r "%USERPROFILE%\.ollama\models" %%F in (*.tmp) do (
    REM Ollama stores models as blobs
    set "blobpath=%%~dpF"
    echo OLLAMA_BLOB %%F >> "%LLM_PATHS_FILE%"
)

:: Safetensors files (HuggingFace format)
echo [Scanning for Safetensor files...]
for %%P in (%SEARCH_PATHS%) do (
    if exist "%%P" (
        for /r "%%P" %%F in (*.safetensors) do (
            echo SAFETENSORS %%F >> "%LLM_PATHS_FILE%"
        )
    )
)

:: Scan each drive letter for GGUF files
echo [Scanning all drives for GGUF files...]
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%D:\" (
        echo    Scanning %%D: drive...
        for /r %%D:\ %%F in (*.gguf) do (
            echo GGUF %%F >> "%LLM_PATHS_FILE%"
        )
        for /r %%D:\ %%F in (*.safetensors) do (
            echo SAFETENSORS %%F >> "%LLM_PATHS_FILE%"
        )
    )
)

:: Query Ollama API for installed models if running
curl -s http://localhost:11434/api/tags >nul 2>&1
if %errorlevel% equ 0 (
    echo [Fetching Ollama installed models...]
    curl -s http://localhost:11434/api/tags > "%TEMP%\ollama_models.json"
)

:: Count found files
set "GGUF_COUNT=0"
set "OLLAMA_COUNT=0"
set "SAFE_COUNT=0"

if exist "%LLM_PATHS_FILE%" (
    findstr /c:"GGUF" "%LLM_PATHS_FILE%" >nul 2>&1 && (
        for /f %%A in ('findstr /c:"GGUF" "%LLM_PATHS_FILE%" ^| find /c /v ""') do set "GGUF_COUNT=%%A"
    )
    findstr /c:"OLLAMA" "%LLM_PATHS_FILE%" >nul 2>&1 && (
        for /f %%A in ('findstr /c:"OLLAMA" "%LLM_PATHS_FILE%" ^| find /c /v ""') do set "OLLAMA_COUNT=%%A"
    )
    findstr /c:"SAFETENSORS" "%LLM_PATHS_FILE%" >nul 2>&1 && (
        for /f %%A in ('findstr /c:"SAFETENSORS" "%LLM_PATHS_FILE%" ^| find /c /v ""') do set "SAFE_COUNT=%%A"
    )
)

echo.
echo    Found models:
echo    - %GGUF_COUNT% GGUF files
echo    - %OLLAMA_COUNT% Ollama models  
echo    - %SAFE_COUNT% Safetensor files

:: Save to public folder for browser
if not exist "public" mkdir public
copy "%LLM_PATHS_FILE%" "public\llm_models.txt" >nul 2>&1

:: ============================================
:: STEP 5: Detect GPU and Optimize Settings
:: ============================================
echo [5/7] Detecting hardware...

:: GPU Detection via DirectX
dxdiag /x "%TEMP%\dxdiag_odt.xml" >nul 2>&1
if exist "%TEMP%\dxdiag_odt.xml" (
    findstr /i "NVIDIA" "%TEMP%\dxdiag_odt.xml" >nul 2>&1 && echo    GPU: NVIDIA detected
    findstr /i "AMD" "%TEMP%\dxdiag_odt.xml" >nul 2>&1 && echo    GPU: AMD detected
    findstr /i "Intel" "%TEMP%\dxdiag_odt.xml" >nul 2>&1 && echo    GPU: Intel detected
    del "%TEMP%\dxdiag_odt.xml"
)

:: CPU cores
for /f "tokens=2" %%A in ('systeminfo ^| findstr /c:"Processor(s)"') do (
    for /f "tokens=1" %%B in ("%%A") do echo    CPU: %%B cores
)

:: RAM
for /f "tokens=2" %%A in ('systeminfo ^| findstr /c:"Total Physical Memory"') do (
    echo    RAM: %%A
)

:: ============================================
:: STEP 6: Configure Network Settings
:: ============================================
echo [6/7] Configuring network settings...

if "%NETWORK_TYPE%"=="tmobile_5g" (
    echo    [5G HOME INTERNET DETECTED]
    echo    Creating T-Mobile optimized config...
    echo.
    echo    T-Mobile uses CGNAT - tunnel will auto-configure
    echo    You can use ngrok or cloudflared for external access
)

if "%NETWORK_TYPE%"=="wifi" (
    echo    WiFi network detected
    echo    Network access: http://192.168.x.x:8080
)

if "%NETWORK_TYPE%"=="wired" (
    echo    Wired network detected
    echo    Network access: Check your IP address
)

:: ============================================
:: STEP 7: Create Desktop Shortcuts
:: ============================================
echo [7/7] Creating shortcuts...

set "DESKTOP=%USERPROFILE%\Desktop"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"

if exist "%DESKTOP%" (
    copy "START-ODT.bat" "%DESKTOP%\ODT - Omni Development Terminal.bat"
    echo    Desktop shortcut created
)

if exist "%STARTMENU%" (
    copy "START-ODT.bat" "%STARTMENU%\ODT - Omni Development Terminal.bat"
    echo    Start Menu shortcut created
)

:: ============================================
:: FINISH
:: ============================================
echo.
echo  ================================================
echo   SETUP COMPLETE!
echo  ================================================
echo.
echo  ODT Models Directory: %USERPROFILE%\.ollama\models
echo.
echo  To download models:
echo    ollama pull llama3
echo    ollama pull qwen2.5
echo    ollama pull mistral
echo.
echo  Run ODT now? (Y/N)
choice /c YN /n
if errorlevel 2 goto :end

:start_odt
echo.
echo  Starting ODT...
start "ODT-Server" cmd /k "node proxy.js"
timeout /t 3 /nobreak >nul
start http://localhost:8080
goto :end

:end
echo.
echo  To start ODT manually, run START-ODT.bat
pause