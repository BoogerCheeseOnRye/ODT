@echo off
title ODT Setup Wizard
color 0A
cd /d "E:\ODT(ignore do not delete)\backup4"

echo.
echo  ================================================
echo   ODT Setup Wizard - Omni Development Terminal
echo  ================================================
echo.

:: Check for admin/elevated privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Running setup...
)

:: ============================================
:: STEP 1: Check Internet Connection
:: ============================================
echo [1/6] Checking network connection...

:: Test different network types
ping -n 1 8.8.8.8 >nul 2>&1
set "NETWORK_TYPE=unknown"
if %errorlevel% equ 0 set "NETWORK_TYPE=wired"

:: Check for common 5G wireless indicators
ipconfig | findstr /i "192.168.168" >nul 2>&1
if %errorlevel% equ 0 set "NETWORK_TYPE=5g_wireless"

:: Check T-Mobile indicators
ipconfig | findstr /i "192.168.224" >nul 2>&1
if %errorlevel% equ 0 set "NETWORK_TYPE=tmobile_5g"

:: Check WiFi adapter presence
netsh wlan show interfaces | findstr /i "SSID" >nul 2>&1
if %errorlevel% equ 0 (
    if "%NETWORK_TYPE%"=="unknown" set "NETWORK_TYPE=wifi"
)

echo    Network detected: %NETWORK_TYPE%

:: ============================================
:: STEP 2: Check Node.js and Dependencies
:: ============================================
echo [2/6] Checking Node.js...

node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo    Node.js not found! Installing via winget...
    winget install OpenJS.NodeJS --silent --accept-source-agreements --accept-package-agreements
    timeout /t 5 /nobreak >nul
)

node --version
echo    Node.js OK

:: Install dependencies if package.json exists
if exist "package.json" (
    echo    Installing npm dependencies...
    call npm install --silent 2>nul
)

:: ============================================
:: STEP 3: Scan All Drives for GGUF Files
:: ============================================
echo [3/6] Scanning drives for LLM models (this may take a while)...

set "GGUF_PATHS_FILE=%TEMP%\odt_gguf_paths.txt"
if exist "%GGUF_PATHS_FILE%" del "%GGUF_PATHS_FILE%"

:: Common model locations
set "SEARCH_PATHS=C:\ollama-models;D:\OLLAMA\models;E:\ollama-models;%USERPROFILE%\.ollama\models;C:\Users\%USERNAME%\AppData\Local\ollama\models"

:: Scan each drive letter
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%D:\" (
        echo    Scanning %%D: drive...
        for /r %%D:\ %%F in (*.gguf *.bin) do (
            if "%%~xF"==".gguf" (
                echo %%F >> "%GGUF_PATHS_FILE%"
            )
        )
    )
)

:: Also search in common subfolders
for %%P in (%SEARCH_PATHS%) do (
    if exist "%%P" (
        echo    Found models in %%P
        for /r "%%P" %%F in (*.gguf) do (
            echo %%F >> "%GGUF_PATHS_FILE%"
        )
    )
)

:: Count found files
set "GGUF_COUNT=0"
if exist "%GGUF_PATHS_FILE%" (
    for /f %%A in ('type "%GGUF_PATHS_FILE%" ^| find /c /v ""') do set "GGUF_COUNT=%%A"
)
echo    Found %GGUF_COUNT% GGUF files

:: Save to localStorage (will be loaded by browser)
echo %GGUF_COUNT% GGUF files scanned > "%TEMP%\odt_scan_complete.txt"

:: ============================================
:: STEP 4: Detect GPU and Optimize Settings
:: ============================================
echo [4/6] Detecting hardware...

:: GPU Detection via DirectX
dxdiag /x "%TEMP%\dxdiag_odt.xml" >nul 2>&1
if exist "%TEMP%\dxdiag_odt.xml" (
    findstr /i "NVIDIA" "%TEMP%\dxdiag_odt.xml" >nul 2>&1 && echo    GPU: NVIDIA detected
    findstr /i "AMD" "%TEMP%\dxdiag_odt.xml" >nul 2>&1 && echo    GPU: AMD detected
    findstr /i "Intel" "%TEMP%\dxdiag_odt.xml" >nul 2>&1 && echo    GPU: Intel detected
    del "%TEMP%\dxdiag_odt.xml"
)

:: CPU cores
for /f "tokens=2" %%A in ('systeminfo ^| findstr /c:"Processor(s)"') do (
    for /f "tokens=1" %%B in ("%%A") do echo    CPU: %%B cores
)

:: RAM
for /f "tokens=2" %%A in ('systeminfo ^| findstr /c:"Total Physical Memory"') do (
    echo    RAM: %%A
)

:: ============================================
:: STEP 5: Configure Network Settings
:: ============================================
echo [5/6] Configuring network settings...

if "%NETWORK_TYPE%"=="tmobile_5g" (
    echo    [5G HOME INTERNET DETECTED]
    echo    Creating T-Mobile optimized config...
    echo @echo off > configure_tmobile.bat
    echo echo Configuring for T-Mobile 5G... >> configure_tmobile.bat
    echo echo NPM install ngrok >> configure_tmobile.bat
    echo npm install -g ngrok >> configure_tmobile.bat
    echo.
    echo    T-Mobile mode: ngrok tunnel will auto-configure
    echo    You can use ngrok or cloudflared for external access
)

if "%NETWORK_TYPE%"=="wifi" (
    echo    WiFi network detected
    echo    Network access: http://192.168.x.x:8080
)

if "%NETWORK_TYPE%"=="wired" (
    echo    Wired network detected
    echo    Network access: Check your IP address
)

:: ============================================
:: STEP 6: Create Desktop Shortcuts
:: ============================================
echo [6/6] Creating shortcuts...

set "DESKTOP=%USERPROFILE%\Desktop"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"

if exist "%DESKTOP%" (
    copy "START-ODT.bat" "%DESKTOP%\ODT - Omni Development Terminal.bat"
    echo    Desktop shortcut created
)

if exist "%STARTMENU%" (
    copy "START-ODT.bat" "%STARTMENU%\ODT - Omni Development Terminal.bat"
    echo    Start Menu shortcut created
)

:: ============================================
:: FINISH
:: ============================================
echo.
echo  ================================================
echo   SETUP COMPLETE!
echo  ================================================
echo.
echo  Run ODT now? (Y/N)
choice /c YN /n
if errorlevel 2 goto :end

:start_odt
echo.
echo  Starting ODT...
start "ODT-Server" cmd /k "node proxy.js"
timeout /t 3 /nobreak >nul
start http://localhost:8080
goto :end

:end
echo.
echo  To start ODT manually, run START-ODT.bat
pause