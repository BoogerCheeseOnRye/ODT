#!/bin/bash
# =====================================================
# ODT Setup Wizard - Cross-Platform (Mac/Linux)
# =====================================================

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
CYAN='\033[0;36m'

echo ""
echo -e "${CYAN}================================================"
echo -e " ODT Setup Wizard - Omni Development Terminal"
echo -e "================================================${NC}"
echo ""

# ============================================
# STEP 1: Check Network Connection
# ============================================
echo -e "${YELLOW}[1/6] Checking network connection...${NC}"

# Detect network type
NETWORK_TYPE="unknown"

# Check if connected
if ping -c 1 8.8.8.8 >/dev/null 2>&1; then
    NETWORK_TYPE="connected"
fi

# Check for wireless
if command -v networksetup >/dev/null 2>&1; then
    # macOS
    WIFI_INFO=$(networksetup -getairportnetwork en0 2>/dev/null || echo "not connected")
    if [[ "$WIFI_INFO" != "not connected" ]]; then
        NETWORK_TYPE="wifi"
    fi
elif command -v iwconfig >/dev/null 2>&1; then
    # Linux
    if iwconfig 2>/dev/null | grep -q "ESSID"; then
        NETWORK_TYPE="wifi"
    fi
fi

# Check for common 5G home internet patterns
GATEWAY=$(route -n get default 2>/dev/null | grep "gateway" | awk '{print $2}' || echo "")
if [[ "$GATEWAY" == "192.168.168."* ]]; then
    NETWORK_TYPE="5g_wireless"
elif [[ "$GATEWAY" == "192.168.224."* ]]; then
    NETWORK_TYPE="tmobile_5g"
fi

# Check T-Mobile specifically
if ifconfig 2>/dev/null | grep -q "192.168.224"; then
    NETWORK_TYPE="tmobile_5g"
fi

echo -e "  Network detected: ${GREEN}$NETWORK_TYPE${NC}"

# ============================================
# STEP 2: Check Node.js and Dependencies
# ============================================
echo -e "${YELLOW}[2/6] Checking Node.js...${NC}"

if ! command -v node >/dev/null 2>&1; then
    echo -e "  ${RED}Node.js not found! Installing...${NC}"
    
    if command -v brew >/dev/null 2>&1; then
        # macOS
        echo -e "  Installing via Homebrew..."
        brew install node
    elif command -v apt >/dev/null 2>&1; then
        # Debian/Ubuntu
        echo -e "  Installing via apt..."
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt-get install -y nodejs
    elif command -v dnf >/dev/null 2>&1; then
        # Fedora/RHEL
        echo -e "  Installing via dnf..."
        curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
        sudo dnf install -y nodejs
    elif command -v pacman >/dev/null 2>&1; then
        # Arch
        echo -e "  Installing via pacman..."
        sudo pacman -S nodejs npm
    else
        echo -e "  ${RED}Cannot detect package manager. Please install Node.js manually.${NC}"
    fi
fi

NODE_VERSION=$(node --version 2>/dev/null || echo "not installed")
echo -e "  Node.js version: ${GREEN}$NODE_VERSION${NC}"

# Install npm dependencies
if [ -f "package.json" ]; then
    echo -e "  Installing npm dependencies..."
    npm install --silent 2>/dev/null || npm install
fi

# ============================================
# STEP 3: Scan All Locations for GGUF Files
# ============================================
echo -e "${YELLOW}[3/6] Scanning drives for LLM models...${NC}"

GGUF_PATHS_FILE="/tmp/odt_gguf_paths.txt"
rm -f "$GGUF_PATHS_FILE"
touch "$GGUF_PATHS_FILE"

# Common model locations per OS
SEARCH_PATHS=""

if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS paths
    SEARCH_PATHS="$HOME/.ollama/models"
    SEARCH_PATHS="$SEARCH_PATHS /System/Volumes/Data/Users/$USER/.ollama/models"
    SEARCH_PATHS="$SEARCH_PATHS /opt/homebrew/share/ollama"
    SEARCH_PATHS="$SEARCH_PATHS /usr/local/share/ollama"
    SEARCH_PATHS="$SEARCH_PATHS ~/Library/Caches/ollama"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux paths
    SEARCH_PATHS="$HOME/.local/share/ollama/models"
    SEARCH_PATHS="$SEARCH_PATHS /usr/share/ollama/models"
    SEARCH_PATHS="$SEARCH_PATHS /opt/ollama/models"
    SEARCH_PATHS="$SEARCH_PATHS /var/lib/ollama/models"
fi

# Common cross-platform paths
SEARCH_PATHS="$SEARCH_PATHS $HOME/ollama-models"
SEARCH_PATHS="$SEARCH_PATHS $HOME/Library/Caches/ollama"
SEARCH_PATHS="$SEARCH_PATHS $HOME/.cache/ollama"

# Search each path
for path in $SEARCH_PATHS; do
    if [ -d "$path" ]; then
        echo -e "  Scanning: $path"
        find "$path" -name "*.gguf" -o -name "*.bin" 2>/dev/null | while read f; do
            if [[ "$f" == *.gguf ]]; then
                echo "$f" >> "$GGUF_PATHS_FILE"
            fi
        done
    fi
done

# Also search common root directories
for mount_point in /Volumes/* /media/* /mnt/*; do
    if [ -d "$mount_point" ] && [ "$mount_point" != "/Volumes/*" ]; then
        echo -e "  Scanning: $mount_point"
        find "$mount_point" -maxdepth 5 -name "*.gguf" 2>/dev/null | head -50 | while read f; do
            echo "$f" >> "$GGUF_PATHS_FILE"
        done
    fi
done

# Sort and dedupe
sort -u "$GGUF_PATHS_FILE" -o "$GGUF_PATHS_FILE" 2>/dev/null || true

# Count files
GGUF_COUNT=$(wc -l < "$GGUF_PATHS_FILE" 2>/dev/null || echo "0")
echo -e "  Found ${GREEN}$GGUF_COUNT${NC} GGUF files"

# Create model list for browser
if [ -d "public" ] || [ -d "www" ]; then
    mkdir -p public www 2>/dev/null
    cp "$GGUF_PATHS_FILE" public/gguf_models.txt 2>/dev/null || true
fi

# ============================================
# STEP 4: Detect GPU and Optimize Settings
# ============================================
echo -e "${YELLOW}[4/6] Detecting hardware...${NC}"

# macOS GPU
if [[ "$OSTYPE" == "darwin"* ]]; then
    if system_profiler SPDisplaysDataType 2>/dev/null | grep -q "Apple M"; then
        echo -e "  GPU: ${GREEN}Apple Silicon (M-series)${NC}"
    elif system_profiler SPDisplaysDataType 2>/dev/null | grep -q "AMD"; then
        echo -e "  GPU: ${GREEN}AMD${NC}"
    elif system_profiler SPDisplaysDataType 2>/dev/null | grep -q "NVIDIA"; then
        echo -e "  GPU: ${GREEN}NVIDIA${NC}"
    fi
fi

# Linux GPU
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if command -v nvidia-smi >/dev/null 2>&1; then
        nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | while read gpu; do
            echo -e "  GPU: ${GREEN}$gpu${NC}"
        done
    elif command -v lspci >/dev/null 2>&1; then
        lspci | grep -i "vga\|3d\|display" | while read gpu; do
            echo -e "  GPU: $gpu"
        done
    fi
fi

# CPU cores
CPU_CORES=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo "unknown")
echo -e "  CPU: ${GREEN}$CPU_CORES${NC} cores"

# RAM
if [[ "$OSTYPE" == "darwin"* ]]; then
    RAM_GB=$(sysctl -n hw.memsize 2>/dev/null | awk '{printf "%.1f", $1/1024/1024/1024}')
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    RAM_GB=$(free -g 2>/dev/null | awk 'NR==2 {print $2}' || echo "unknown")
fi
echo -e "  RAM: ${GREEN}${RAM_GB}GB${NC}"

# ============================================
# STEP 5: Configure Network Settings
# ============================================
echo -e "${YELLOW}[5/6] Configuring network settings...${NC}"

if [ "$NETWORK_TYPE" = "tmobile_5g" ]; then
    echo -e "  ${YELLOW}5G HOME INTERNET DETECTED${NC}"
    echo -e "  - T-Mobile uses CGNAT (no port forwarding)"
    echo -e "  - Will use ngrok/cloudflared tunnel"
    echo -e "  - Run: ./tunnel.sh start"
    
    # Create tunnel script
    cat > tunnel.sh << 'TUNNEL_EOF'
#!/bin/bash
case "$1" in
start)
    echo "Starting tunnel..."
    if command -v cloudflared >/dev/null 2>&1; then
        cloudflared tunnel --url http://localhost:8080
    elif command -v ngrok >/dev/null 2>&1; then
        ngrok http 8080
    else
        echo "Installing cloudflared..."
        curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
        chmod +x cloudflared
        ./cloudflared tunnel --url http://localhost:8080
    fi
    ;;
install)
    if command -v brew >/dev/null 2>&1; then
        brew install cloudflare/cloudflare/cloudflared
    else
        curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
        chmod +x cloudflared
    fi
    ;;
esac
TUNNEL_EOF
    chmod +x tunnel.sh
fi

if [ "$NETWORK_TYPE" = "wifi" ]; then
    echo -e "  WiFi network detected"
    echo -e "  Access from other devices: http://$(hostname -I | awk '{print $1}'):8080"
fi

if [ "$NETWORK_TYPE" = "wired" ]; then
    echo -e "  Wired network detected"
    echo -e "  Access from other devices: http://$(hostname -I | awk '{print $1}'):8080"
fi

# ============================================
# STEP 6: Create Desktop Entry
# ============================================
echo -e "${YELLOW}[6/6] Creating shortcuts...${NC}"

DESKTOP="$HOME/Desktop"
STARTMENU="$HOME/.local/share/applications"

# Create .desktop file for Linux
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    mkdir -p "$STARTMENU"
    cat > "$STARTMENU/odt.desktop" << 'DESKTOP_EOF'
[Desktop Entry]
Name=ODT - Omni Development Terminal
Comment=AI-powered development environment
Exec=bash -c "cd /path/to/odt && ./START-ODT.sh"
Icon=terminal
Terminal=true
Type=Application
Categories=Development;
DESKTOP_EOF
    chmod +x "$STARTMENU/odt.desktop"
    echo -e "  Desktop entry created"
fi

# Create macOS app alias
if [[ "$OSTYPE" == "darwin"* ]]; then
    ln -sf "$(pwd)/START-ODT.sh" "$DESKTOP/ODT.command" 2>/dev/null || true
    echo -e "  Desktop alias created"
fi

# Make scripts executable
chmod +x START-ODT.sh 2>/dev/null || true
chmod +x tunnel.sh 2>/dev/null || true

# ============================================
# FINISH
# ============================================
echo ""
echo -e "${GREEN}================================================"
echo -e " SETUP COMPLETE!"
echo -e "================================================${NC}"
echo ""
read -p "Start ODT now? (Y/n): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Nn]$ ]]; then
    echo -e "Starting ODT..."
    (./START-ODT.sh &)
fi

echo ""
echo -e "To start ODT manually:"
echo -e "  ${CYAN}./START-ODT.sh${NC}"
if [ "$NETWORK_TYPE" = "tmobile_5g" ]; then
    echo -e "To start tunnel (for external access):"
    echo -e "  ${CYAN}./tunnel.sh start${NC}"
fi
echo ""