#!/bin/bash
# =====================================================
# ODT Start Script - Cross-Platform
# =====================================================

# Detect OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    PLATFORM="macos"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    PLATFORM="linux"
else
    PLATFORM="unknown"
fi

echo ""
echo "================================================"
echo " ODT - Omni Development Terminal"
echo " Platform: $PLATFORM"
echo "================================================"
echo ""

# Get local IP for network access
LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "localhost")
if [ "$LOCAL_IP" = "" ]; then
    LOCAL_IP="localhost"
fi

# ============================================
# Start Proxy Server
# ============================================
echo "[1/3] Starting Proxy Server (port 8080)..."

if command -v node >/dev/null 2>&1; then
    if [ "$PLATFORM" = "macos" ]; then
        # macOS - use osascript to open terminal with server
        osascript -e 'tell app "Terminal" to do script "cd \"'$(pwd)'\" && node proxy.js"'
    elif [ "$PLATFORM" = "linux" ]; then
        # Linux - try different terminals
        if command -v gnome-terminal >/dev/null 2>&1; then
            gnome-terminal -- bash -c "cd '$(pwd)' && node proxy.js; exec bash" &
        elif command -v konsole >/dev/null 2>&1; then
            konsole -e "cd '$(pwd)' && node proxy.js" &
        elif command -v xterm >/dev/null 2>&1; then
            xterm -e "cd '$(pwd)' && node proxy.js" &
        else
            # No terminal emulator, run in background
            node proxy.js &
            SERVER_PID=$!
            echo "Server started (PID: $SERVER_PID)"
        fi
    else
        node proxy.js &
        SERVER_PID=$!
    fi
else
    echo "ERROR: Node.js not found!"
    echo "Please install Node.js first"
    exit 1
fi

# Wait for server to start
sleep 3

# ============================================
# Open Browser
# ============================================
echo "[2/3] Opening ODT in browser..."

if [ "$PLATFORM" = "macos" ]; then
    open http://localhost:8080
else
    xdg-open http://localhost:8080 2>/dev/null || start http://localhost:8080 2>/dev/null || echo "Please open http://localhost:8080 in your browser"
fi

# ============================================
# Show Status
# ============================================
echo "[3/3] Done!"
echo ""
echo "================================================"
echo " SERVERS STARTED:"
echo " - Proxy:    http://localhost:8080"
echo " - Network:  http://$LOCAL_IP:8080"
echo " - Swarm:   ws://localhost:9002/swarm"
echo "================================================"
echo ""
echo " To stop ODT: close the server terminal window"
echo ""

# Keep script running if in foreground
if [ "$PLATFORM" = "linux" ] && ! command -v gnome-terminal >/dev/null 2>&1 && ! command -v konsole >/dev/null 2>&1; then
    echo "Server is running in background."
    echo "Press Ctrl+C to stop"
    wait $SERVER_PID 2>/dev/null
fi