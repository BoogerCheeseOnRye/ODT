@echo off
title ODT Server
color 0A
cd /d "E:\ODT(ignore do not delete)\backup4"

echo.
echo  ================================================
echo   ODT - Omni Development Terminal
echo   Double-click this file to start
echo  ================================================
echo.

:: Start proxy server in dedicated window
start "ODT-Server" cmd /k "title ODT Proxy && node proxy.js"

:: Wait for server startup
timeout /t 3 /nobreak >nul

:: Open browser
start http://localhost:8080

echo.
echo  SERVERS STARTED:
echo  - Proxy:    http://localhost:8080
echo  - Swarm:    ws://localhost:9002/swarm
echo  - Ollama:   http://localhost:11434
echo.
echo  To stop ODT: close the "ODT-Server" window
echo.
pause